# 097. 家庭文明不是命运，而是可以被重建的系统

# Family Civilization Is Not Fate, but a System That Can Be Rebuilt

## 中文正文

很多人谈到原生家庭时，会有一种深深的无力感。

他们知道自己受过伤，知道家庭关系出了问题，知道父母的控制、羞辱、冷漠、暴力、情感勒索和道德绑架影响了自己的一生。可是他们同时又觉得：这已经是命了。童年已经过去，父母不会改变，伤害已经发生，人生只能这样。

这种无力感，是很多受伤者第二次被困住的原因。

第一次被困住，是小时候没有能力逃离伤害。

第二次被困住，是成年以后仍然相信自己只能由过去决定。

家庭文明必须提出一个不同的答案：家庭不是命运。家庭是一种系统。

只要是系统，就可以被认识；只要可以被认识，就可以被重新设计；只要可以被重新设计，就可以被一点点改变。

一个家庭之所以反复制造伤害，往往不是因为其中每一个人天生邪恶，而是因为这个家庭内部长期运行着一套错误的关系系统。

这套系统可能包括：权力高于尊重，服从高于理解，面子高于人格，成功高于幸福，控制高于边界，沉默高于表达，牺牲高于自由，血缘高于正义。

在这样的系统里，哪怕父母有爱，也容易把爱表达成伤害；哪怕孩子渴望靠近，也容易用逃离保护自己；哪怕夫妻都不想伤害孩子，也可能在冲突中把孩子卷入自己的痛苦。

因此，家庭文明不是简单地把问题归结为某一个人坏，也不是要求所有人靠意志瞬间改变。家庭文明首先要做的，是让家庭成员看见：关系痛苦不是凭空发生的，它有结构，有语言，有习惯，有权力机制，有情绪模式，有代际来源。

看见系统，是重建系统的第一步。

第一，家庭中的伤害模式可以被识别。

一个家庭里反复出现的争吵，往往不是每一次都全新发生。它们常常有固定模式。父母焦虑，开始控制。孩子反抗，父母感到失控。父母加重指责，孩子沉默或爆发。父母把沉默理解为冷漠，把爆发理解为不孝。孩子把父母的指责理解为不爱，把父母的控制理解为侵犯。最后，所有人都觉得自己受伤，所有人都觉得对方不理解自己。

如果没有系统视角，这一切就会被理解为“孩子不懂事”“父母太强势”“夫妻不合”“性格不合”。但从家庭文明的角度看，这是一种可以被识别的关系循环。只要循环被识别，它就不再完全控制人。

第二，家庭中的语言系统可以被改写。

很多家庭的伤害，是通过语言发生的。

“我都是为你好。”

“你怎么这么没用？”

“你看看别人家的孩子。”

“我养你这么大，你就这样对我？”

“你再这样，我就不要你了。”

“你必须听我的。”

这些话不仅是句子，更是一套权力语言。它们制造羞耻、恐惧、内疚、服从和自我否定。

家庭文明要求把这种语言系统改写为尊重语言、边界语言、感受语言、责任语言和协商语言。

“我有担心，但我愿意听你说。”

“这件事我不同意，但我不否定你这个人。”

“我很受伤，需要一点时间冷静。”

“我希望我们能一起找到一个不互相伤害的方式。”

“你的选择属于你，我可以表达意见，但不能替你活。”

语言改变，不只是表达技巧改变。语言改变，是关系结构的改变。

第三，家庭中的权力结构可以被转化。

很多传统家庭之所以痛苦，是因为它把家庭理解为等级结构。父母高于孩子，丈夫高于妻子，长辈高于晚辈，成功者高于失败者，付出者高于接受者。在这样的结构里，关系天然不平等，伤害很容易被解释成教育、关心、孝顺、责任或家法。

家庭文明要重建的，不是让家庭没有秩序，而是让家庭秩序从权力秩序转向文明秩序。文明秩序不是没有父母责任，不是没有长幼差异，不是没有教育和引导。文明秩序的核心是：任何角色都不能取消一个人的人格尊严。

父母可以引导孩子，但不能羞辱孩子。

长辈可以表达经验，但不能控制晚辈人生。

夫妻可以有分工，但不能把对方当工具。

家庭可以有责任，但不能用责任消灭自由。

第四，家庭中的情绪模式可以被训练。

很多家庭的痛苦，不是因为没有道理，而是因为情绪一来，道理就消失了。父母一焦虑就控制，孩子一害怕就沉默，夫妻一受伤就攻击，成年人一感到失败就迁怒孩子。

如果一个家庭没有情绪训练，关系就会被自动反应支配。

家庭文明要帮助家庭建立新的情绪规则：情绪可以表达，但不能用伤害表达；愤怒可以被承认，但不能变成暴力；失望可以被说出，但不能变成羞辱；痛苦可以被看见，但不能要求孩子承担；冲突可以暂停，但不能用冷暴力惩罚。

这不是要求人没有情绪，而是让情绪进入文明边界。

第五，家庭中的代际模式可以被阻断。

很多父母并不是凭空学会控制、打骂、羞辱和情绪勒索的。他们也曾经是孩子，也曾经在旧家庭、旧文化、旧权力结构里被塑造。

看见这一点，不是为了替伤害开脱，而是为了让修复更清醒。一个人如果不知道自己正在重复上一代，就会把重复误认为本能。

父亲被打过，就以为打孩子是正常教育。母亲被牺牲过，就以为牺牲孩子是家庭责任。上一代没有边界，下一代就继续不知道什么是边界。上一代把爱变成控制，下一代就继续把控制误认为爱。

家庭文明的意义，是让这种无意识重复被打断。

伤口到我为止，不是一句口号，而是一种系统重建。

第六，家庭中的行动流程可以被设计。

很多家庭不是不想改变，而是不知道如何开始。家庭文明可以把改变设计成具体流程：每周一次家庭会议；每次冲突后一次复盘；每次伤害后一次具体道歉；每个家庭成员都有表达感受的时间；父母不打断孩子说完三分钟；夫妻冲突不在孩子面前升级；重大决定之前先区分事实、情绪、需求和责任。

这些流程看似简单，却能慢慢改变家庭的底层运行方式。一个家庭的命运，不是由口号改变的，而是由重复发生的新行为改变的。

第七，AI家庭文明顾问可以帮助系统重建更容易开始。

家庭系统的重建，需要记录、提醒、复盘、反馈和持续练习。仅靠个人意志很难长期坚持，尤其在充满冲突的家庭里，人们很容易回到旧模式。

AI家庭文明顾问可以帮助家庭把混乱变成可见，把争吵变成记录，把伤害变成可讨论的问题，把抽象理念变成下一步行动。它不能替代人的责任，但可以降低改变的门槛；它不能替代爱，但可以帮助爱少一点伤害；它不能替代家庭成员成长，但可以让成长更有路径。

家庭文明不是命运，因为命运意味着只能承受。

家庭文明是系统，因为系统意味着可以理解、可以调整、可以训练、可以重建。

一个人不能重新选择自己的出生家庭。但一个人可以重新理解自己的家庭模式。

一个家庭不能取消过去发生过的伤害。但一个家庭可以决定是否继续重复那些伤害。

一个社会不能指望家庭自然变得文明。但一个社会可以开始建设家庭文明的语言、工具、方法、系统和AI助理。

家庭文明的希望，正是在这里。

过去的家庭造成了伤害，不代表未来的家庭只能继续伤害。

旧系统制造了痛苦，不代表新系统不能被建立。

人类曾经用工程方法建设道路、桥梁、城市、学校、医院和互联网。现在，人类也应当用工程方法建设家庭文明。

家庭文明不是命运。

家庭文明，是可以被重建的系统。

* * *

## English Version

When many people speak about their family of origin, they feel a deep helplessness.

They know they were wounded. They know that their family relationships went wrong. They know that parental control, humiliation, coldness, violence, emotional blackmail, and moral coercion shaped their lives. But at the same time, they feel that this is fate. Childhood has already passed. Parents will not change. The harm has already happened. Life can only be this way.

This helplessness is the second prison of many wounded people.

The first prison was being unable to escape harm as a child.

The second prison is believing, as an adult, that one can only be determined by the past.

Family Civilization must offer a different answer: family is not fate. Family is a system.

If something is a system, it can be understood. If it can be understood, it can be redesigned. If it can be redesigned, it can be gradually changed.

A family that repeatedly creates harm is often not composed of people who are naturally evil. Rather, it is usually running a wrong relational system over a long period of time.

This system may include power above respect, obedience above understanding, face above personhood, success above happiness, control above boundaries, silence above expression, sacrifice above freedom, and blood ties above justice.

Within such a system, even if parents have love, they may easily express love as harm. Even if children long for closeness, they may use escape to protect themselves. Even if couples do not want to harm the child, they may still pull the child into their pain during conflict.

Therefore, Family Civilization does not simply reduce the problem to one bad person, nor does it require everyone to change instantly through willpower. Its first task is to help family members see that relational suffering does not happen out of nowhere. It has structure, language, habits, power mechanisms, emotional patterns, and intergenerational origins.

Seeing the system is the first step in rebuilding the system.

First, harmful patterns in the family can be identified.

Repeated quarrels in a family are often not entirely new each time. They usually have fixed patterns. Parents become anxious and begin to control. The child resists, and parents feel out of control. Parents increase criticism, and the child becomes silent or explodes. Parents interpret silence as coldness and explosion as unfilial behavior. The child interprets parental criticism as lack of love and parental control as violation. Finally, everyone feels wounded, and everyone feels misunderstood by the other.

Without a systemic view, all of this is understood merely as “the child is immature,” “the parents are too strong,” “the couple does not get along,” or “their personalities are incompatible.” But from the perspective of Family Civilization, this is an identifiable relational cycle. Once the cycle is identified, it no longer fully controls people.

Second, the language system in the family can be rewritten.

Much harm in families happens through language. “I am doing this for your own good.” “Why are you so useless?” “Look at other people’s children.” “I raised you, and this is how you treat me?” “If you keep doing this, I will no longer want you.” “You must listen to me.” These are not merely sentences. They are a language of power. They create shame, fear, guilt, obedience, and self-denial.

Family Civilization requires this language system to be rewritten into the language of respect, boundaries, feelings, responsibility, and consultation: “I am worried, but I am willing to hear you.” “I disagree with this matter, but I do not deny you as a person.” “I am hurt and need some time to calm down.” “I hope we can find a way that does not harm each other.” “Your choice belongs to you. I can express my view, but I cannot live your life for you.”

Changing language is not merely changing communication skills. It is changing the structure of relationship.

Third, the power structure in the family can be transformed.

Many traditional families suffer because they understand the family as a hierarchy: parents above children, husband above wife, elders above the young, the successful above the unsuccessful, those who sacrifice above those who receive. In such a structure, relationships are naturally unequal, and harm is easily explained as education, concern, filial duty, responsibility, or family discipline.

What Family Civilization seeks to rebuild is not a family without order, but a family whose order moves from power order to civilizational order. Civilizational order does not mean the absence of parental responsibility, generational difference, education, or guidance. Its core is that no role may cancel a person’s dignity.

Parents may guide children, but may not humiliate them. Elders may express experience, but may not control the lives of younger people. Couples may divide responsibilities, but may not treat each other as tools. A family may have duties, but duty must not destroy freedom.

Fourth, emotional patterns in the family can be trained.

Much family pain does not come from the absence of reason. It comes from the fact that once emotion arrives, reason disappears. Parents control when they become anxious. Children become silent when they feel afraid. Couples attack when they are hurt. Adults displace their sense of failure onto children.

If a family has no emotional training, the relationship will be ruled by automatic reactions.

Family Civilization helps families establish new emotional rules: emotion may be expressed, but not through harm; anger may be acknowledged, but must not become violence; disappointment may be spoken, but must not become humiliation; pain may be seen, but must not be assigned to the child to carry; conflict may be paused, but silence must not become punishment.

This is not a demand that people have no emotions. It is the entry of emotion into civilizational boundaries.

Fifth, intergenerational patterns in the family can be interrupted.

Many parents did not learn control, beating, shaming, and emotional blackmail from nowhere. They were once children themselves, shaped by old families, old culture, and old power structures.

Seeing this does not excuse harm. It makes repair clearer. If a person does not know that he is repeating the previous generation, he may mistake repetition for instinct.

A father who was beaten may think beating a child is normal education. A mother who was sacrificed may think sacrificing the child is family duty. When the previous generation had no boundaries, the next generation may still not know what boundaries are. When the previous generation turned love into control, the next generation may continue mistaking control for love.

The meaning of Family Civilization is to interrupt this unconscious repetition.

“Let the wound stop here” is not a slogan. It is the rebuilding of a system.

Sixth, action processes in the family can be designed.

Many families do not lack the desire to change. They lack the knowledge of how to begin. Family Civilization can design change into concrete processes: one family meeting each week; one review after each conflict; one specific apology after each harm; time for each family member to express feelings; parents do not interrupt the child for three minutes; couple conflict does not escalate in front of the child; before major decisions, the family separates facts, emotions, needs, and responsibilities.

These processes may seem simple, but they can slowly change the operating system of the family. The fate of a family is not changed by slogans. It is changed by new behaviors that repeat.

Seventh, the AI Family Civilization Advisor can make system rebuilding easier to begin.

Rebuilding a family system requires recording, reminding, reviewing, feedback, and continuous practice. It is difficult to rely on individual willpower alone, especially in families filled with conflict, where people easily return to old patterns.

The AI Family Civilization Advisor can help a family turn chaos into something visible, conflict into records, harm into discussable issues, and abstract ideas into next steps. It cannot replace human responsibility, but it can lower the threshold of change; it cannot replace love, but it can help love cause less harm; it cannot replace the growth of family members, but it can give growth a clearer path.

Family Civilization is not fate, because fate means only enduring.

Family Civilization is a system, because system means it can be understood, adjusted, trained, and rebuilt.

A person cannot choose the family into which he was born. But a person can reinterpret the family patterns he inherited.

A family cannot erase the harm that has already happened. But a family can decide whether to continue repeating that harm.

A society cannot expect families to become civilized naturally. But a society can begin to build the language, tools, methods, systems, and AI assistants of Family Civilization.

The hope of Family Civilization lies here.

A family that caused harm in the past does not mean the family of the future must continue to harm.

An old system created pain does not mean a new system cannot be built.

Humanity has used engineering methods to build roads, bridges, cities, schools, hospitals, and the internet. Now humanity should also use engineering methods to build Family Civilization.

Family Civilization is not fate.

Family Civilization is a system that can be rebuilt.
